# ---------------------------------------------------------------------
# Script: 01_dem_acquisition_processing.py
# Description: Download USGS DEM tiles and combine into single raster
#
# Author: Ashish Shrestha
# Last Updated: 04-28-2026
# ---------------------------------------------------------------------

from pathlib import Path
import sys
import yaml

# Add repository root to Python path
REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(REPO_ROOT))

from src.dem.download_dem import read_dem_urls, download_dem_files
from src.dem.mosaic_dem import mosaic_rasters


def load_config(config_path):
    """
    
    Load YAML configuration file
    
    """
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def main():
    config_path = REPO_ROOT / "configs" / "example.yml"
    config = load_config(config_path)
    city_name = config["city_name"]
    working_folder = config["paths"]["working_folder"]
    dem_url_file = config["paths"]["dem_url_file"]
    output_mosaic = config["paths"]["output_mosaic"]
    max_workers = config["download"].get("max_workers", 10)
    print(f"Executing DEM acquisition and processing for {city_name}...")
    urls = read_dem_urls(dem_url_file)

    download_dem_files(
        urls=urls,
        output_dir=working_folder,
        max_workers=max_workers,
    )

    mosaic_rasters(
        input_folder=working_folder,
        output_path=output_mosaic,
    )

    print("Completed: Algorithm 1")


if __name__ == "__main__":
    main()