# -----------------------------------------------------------------------------
# Script: 03_overpass_removal.py
# Description: Download OSM bridge/overpass features and correct DEM elevations
#
# Author: Ashish Shrestha
# Last Updated: 04-28-2026
# -----------------------------------------------------------------------------

from pathlib import Path
import sys
import yaml

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(REPO_ROOT))

from src.terrain_correction.download_overpass_osm import download_osm_bridges
from src.terrain_correction.process_overpass import (
    buffer_overpass_features,
    rasterize_overpass_features,
)
from src.terrain_correction.correct_dem_overpass import (
    apply_minimum_filter,
    remove_overpass_elevations,
)

def load_config(config_path):
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def main():
    config_path = REPO_ROOT / "configs" / "local.yml"
    if not config_path.exists():
        config_path = REPO_ROOT / "configs" / "example.yml"
    config = load_config(config_path)
    overpass_cfg = config["overpass"]
    print("Executing overpass correction workflow...")
    download_osm_bridges(
        bbox=overpass_cfg["bbox"],
        output_shapefile=overpass_cfg["bridges_shp"],
        reference_file=overpass_cfg["reference_file"],
    )
    buffer_overpass_features(
        input_shapefile=overpass_cfg["bridges_shp"],
        output_shapefile=overpass_cfg["buffered_shp"],
        buffer_distance=overpass_cfg.get("buffer_distance", 15),
    )
    rasterize_overpass_features(
        buffered_shapefile=overpass_cfg["buffered_shp"],
        reference_raster=overpass_cfg["dtm_raster"],
        output_raster=overpass_cfg["bridge_raster"],
    )
    apply_minimum_filter(
        dtm_raster=overpass_cfg["dtm_raster"],
        output_raster=overpass_cfg["focal_stat_raster"],
        filter_size=overpass_cfg.get("filter_size", 25),
    )
    remove_overpass_elevations(
        dtm_raster=overpass_cfg["dtm_raster"],
        bridge_raster=overpass_cfg["bridge_raster"],
        filtered_dtm_raster=overpass_cfg["focal_stat_raster"],
        output_raster=overpass_cfg["dtm_without_bridge"],
    )
    print("Algorithm 3 complete.")

if __name__ == "__main__":
    main()