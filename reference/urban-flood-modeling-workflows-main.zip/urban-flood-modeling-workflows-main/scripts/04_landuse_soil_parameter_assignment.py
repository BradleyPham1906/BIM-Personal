# -----------------------------------------------------------------------------------------------------
# Script: 04_landuse_soil_parameter_assignment.py
# Description: Prepare land cover / use and soil data and generate Mannings n and Green Ampt tables
#
# Author: Ashish Shrestha
# Last Updated: 04-30-2026
# -----------------------------------------------------------------------------------------------------

from pathlib import Path
import sys
import yaml

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(REPO_ROOT))
from src.hydrologic_parameters.prepare_landuse import prepare_landuse_raster
from src.hydrologic_parameters.prepare_soils import clip_and_classify_soils
from src.hydrologic_parameters.manning_table import create_manning_table
from src.hydrologic_parameters.greenampt_table import (
    create_greenampt_soil_only_table,
    create_greenampt_soil_landuse_table,
)

def load_config(config_path):
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def get_config():
    local_config = REPO_ROOT / "configs" / "local.yml"
    example_config = REPO_ROOT / "configs" / "example.yml"
    if local_config.exists():
        return load_config(local_config)
    return load_config(example_config)

def main():
    config = get_config()
    cfg = config["hydrologic_parameters"]
    print("Executing Algorithm 4: Land cover / use and soil parameter assignment.....")
    landuse_raster = prepare_landuse_raster(
        landuse_cfg=cfg["landuse"],
        boundary_path=cfg["boundary_shapefile"],
    )
    soil_shapefile = clip_and_classify_soils(
        soil_shapefile=cfg["soil_shapefile"],
        boundary_shapefile=cfg["boundary_shapefile"],
        output_shapefile=cfg["soils"]["output_clipped_soil"],
        soil_class_column=cfg["soils"].get("soil_class_column"),
        soil_texture_column=cfg["soils"].get("soil_texture_column"),
    )
    create_manning_table(
        landuse_raster=landuse_raster,
        output_csv=cfg["outputs"]["manning_csv"],
    )
    create_greenampt_soil_only_table(
        soil_shapefile=soil_shapefile,
        output_csv=cfg["outputs"]["greenampt_soil_only_csv"],
        effective_saturation=cfg["greenampt"].get("effective_saturation", 0.44),
    )
    if cfg["greenampt"].get("option", 2) == 2:
        create_greenampt_soil_landuse_table(
            soil_shapefile=soil_shapefile,
            landuse_raster=landuse_raster,
            output_csv=cfg["outputs"]["greenampt_soil_landuse_csv"],
            effective_saturation=cfg["greenampt"].get("effective_saturation", 0.44),
        )
    print("Completed Algorithm 4")

if __name__ == "__main__":
    main()