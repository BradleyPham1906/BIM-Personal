# -------------------------------------------------------------
# Script: 02_building_dem_integration.py
# Description: Download OvertureMaps buildings and integrate building heights into DEM
#
# Author: Ashish Shrestha
# Last Updated: 04-28-2026
# -------------------------------------------------------------

from pathlib import Path
import sys
import yaml

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(REPO_ROOT))

from src.buildings.download_overture_buildings import (
    download_overture_buildings,
    convert_geojson_to_shapefile,
)
from src.buildings.process_buildings import (
    project_and_clip_buildings,
    assign_building_heights,
)
from src.buildings.rasterize_buildings import rasterize_buildings
from src.buildings.add_buildings_to_dem import add_buildings_to_dem

def load_config(config_path):
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def main():
    config = load_config(REPO_ROOT / "configs" / "example.yml")

    city_name = config["city_name"]
    dem_raster = config["paths"]["output_mosaic"]
    building_cfg = config["building"]
    print(f"Executing building-DEM integration for {city_name}...")

    download_overture_buildings(
        bbox=building_cfg["bbox"],
        output_geojson=building_cfg["geojson_file"],
        overturemaps_exe=building_cfg["overturemaps_exe"],
    )

    convert_geojson_to_shapefile(
        input_geojson=building_cfg["geojson_file"],
        output_shapefile=building_cfg["shapefile_output"],
    )

    project_and_clip_buildings(
        building_shapefile=building_cfg["shapefile_output"],
        dem_raster=dem_raster,
        output_shapefile=building_cfg["projected_buildings"],
    )

    assign_building_heights(
        input_shapefile=building_cfg["projected_buildings"],
        output_shapefile=building_cfg["buildings_with_height"],
        fallback_height=building_cfg["fallback_height"],
        use_height_attribute=building_cfg.get("use_height_attribute", True),
    )

    rasterize_buildings(
        buildings_shapefile=building_cfg["buildings_with_height"],
        reference_dem=dem_raster,
        output_raster=building_cfg["building_raster"],
    )

    add_buildings_to_dem(
        dem_raster=dem_raster,
        building_raster=building_cfg["building_raster"],
        output_dem=building_cfg["dem_with_buildings"],
    )

    print("Completed: Algorithm 2")


if __name__ == "__main__":
    main()