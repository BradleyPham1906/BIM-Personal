# -------------------------------------------------------------------
# Script: 07_hecras_execution_postprocessing.py
# Description: Generate flood depth rasters from HEC-RAS HDF results
#
# Author: Ashish Shrestha
# Last Updated: 05-01-2026
# -------------------------------------------------------------------

from pathlib import Path
import yaml

from src.postprocessing.read_hecras_hdf import read_hecras_2d_results
from src.postprocessing.calculate_depth_rasters import write_depth_rasters

def load_config(config_path):
    """
    
    Load YAML configuration file
    
    """
    with open(config_path, "r") as f:
        return yaml.safe_load(f)

def main(config_path):
    config = load_config(config_path)
    if "hecras_postprocessing" not in config:
        raise KeyError("Missing 'hecras_postprocessing' section in config.")
    cfg = config["hecras_postprocessing"]
    hdf_file = cfg["hdf_file"]
    terrain_raster = cfg["terrain_raster"]
    output_dir = cfg["output_dir"]
    coords, water_surface, area_name = read_hecras_2d_results(hdf_file)
    write_depth_rasters(
        coords=coords,
        water_surface_all=water_surface,
        terrain_raster_path=terrain_raster,
        output_dir=output_dir,
        hecras_grid_resolution=cfg["hecras_grid_resolution"],
        model_units=cfg.get("model_units", "meters"),
        output_depth_units=cfg.get("output_depth_units", "meters"),
        output_resolution=cfg.get("output_resolution"),
        depth_threshold=cfg.get("depth_threshold", 0.001),
        timestep_minutes=cfg.get("timestep_minutes", 5),
        max_search_distance=cfg.get("max_search_distance"),
        terrain_resampling_method=cfg.get("terrain_resampling_method", "bilinear"),
    )

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(
        description="HEC-RAS HDF postprocessing to generate flood depth rasters"
    )
    parser.add_argument(
        "--config",
        required=True,
        help="Path to YAML configuration file"
    )
    args = parser.parse_args()
    main(args.config)