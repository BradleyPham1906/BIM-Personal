# -------------------------------------------------------------------
# Script: 05_generate_chicago_design_storm.py
# Description: Generate Chicago design storm from NOAA Atlas 14 data
#
# Author: Ashish Shrestha
# Last Updated: 04-30-2026
# -------------------------------------------------------------------

from pathlib import Path
import sys
import yaml
import pandas as pd

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(REPO_ROOT))
from src.rainfall.download_noaa_atlas14 import (
    download_atlas14_depth_table,
    get_atlas_units,
    safe_label,
)
from src.rainfall.parse_noaa_atlas14 import read_noaa_csv, get_noaa_depth
from src.rainfall.fit_idf import fit_idf
from src.rainfall.generate_chicago_storm import chicago_hyetograph_hnh
from src.rainfall.rainfall_reduction import (
    compute_reduction_factor,
    apply_rainfall_reduction,
)
from src.rainfall.plot_hyetograph import plot_hyetograph

def load_config(config_path):
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def get_config():
    local_config = REPO_ROOT / "configs" / "local.yml"
    example_config = REPO_ROOT / "configs" / "example.yml"
    if local_config.exists():
        return load_config(local_config)
    return load_config(example_config)

def main():
    config = get_config()
    cfg = config["rainfall"]
    print("Executing Algorithm 5: Rainfall Atlas 14 download and design storm generation...")
    output_folder = Path(cfg["output_folder"])
    output_folder.mkdir(parents=True, exist_ok=True)
    _, depth_unit, _ = get_atlas_units(cfg["units"])
    atlas_csv = download_atlas14_depth_table(
        latitude=cfg["latitude"],
        longitude=cfg["longitude"],
        output_folder=output_folder,
        location_name=cfg["location_name"],
        units=cfg["units"],
        overwrite=True,
    )
    noaa_table, _ = read_noaa_csv(atlas_csv)
    a, b, c, r2 = fit_idf(
        noaa_table=noaa_table,
        return_period=cfg["return_period"],
    )
    hyetograph = chicago_hyetograph_hnh(
        duration_hours=cfg["duration_hours"],
        dt_minutes=cfg["dt_minutes"],
        a=a,
        b=b,
        c=c,
        r=cfg["peak_ratio"],
    )
    if cfg.get("apply_reduction", False):
        original_depth = get_noaa_depth(
            noaa_table=noaa_table,
            return_period=cfg["return_period"],
            duration_hours=cfg["duration_hours"],
        )
        design_depth = get_noaa_depth(
            noaa_table=noaa_table,
            return_period=cfg["design_return_period"],
            duration_hours=cfg["design_duration_hours"],
        )
        reduction_factor = compute_reduction_factor(
            original_depth=original_depth,
            design_depth=design_depth,
        )
        hyetograph = apply_rainfall_reduction(
            hyetograph=hyetograph,
            reduction_factor=reduction_factor,
        )
    duration_label = str(cfg["duration_hours"]).replace(".0", "")
    return_period_label = safe_label(cfg["return_period"])
    rainfall_txt = output_folder / (
        f"Rainfall_Scenario_{duration_label}hr_Return_period_{return_period_label}yr.txt"
    )
    rainfall_reduced_txt = output_folder / (
        f"Rainfall_Reduced_Scenario_{duration_label}hr_Return_period_{return_period_label}yr.txt"
    )
    rainfall_csv = output_folder / (
        f"Rainfall_Scenario_{duration_label}hr_Return_period_{return_period_label}yr.csv"
    )
    plot_file = output_folder / (
        f"Hyetograph_Scenario_{duration_label}hr_Return_period_{return_period_label}yr.png"
    )
    hyetograph["time"] = hyetograph["time_min"] * 60.0
    hyetograph[["time", "depth"]].to_csv(
        rainfall_txt,
        sep="\t",
        index=False,
        header=False,
        float_format="%.6f",
    )
    if cfg.get("apply_reduction", False):
        hyetograph[["time", "reduced_depth"]].to_csv(
            rainfall_reduced_txt,
            sep="\t",
            index=False,
            header=False,
            float_format="%.6f",
        )
        csv_output = hyetograph[["time", "depth", "reduced_depth"]].copy()
        csv_output.columns = [
            "time (s)",
            f"rainfall ({depth_unit})",
            f"reduced_rainfall ({depth_unit})",
        ]

    else:
        csv_output = hyetograph[["time", "depth"]].copy()
        csv_output.columns = [
            "time (s)",
            f"rainfall ({depth_unit})",
        ]
    csv_output.to_csv(
        rainfall_csv,
        index=False,
        float_format="%.6f",
    )
    plot_hyetograph(
        hyetograph=hyetograph,
        output_file=plot_file,
        dt_minutes=cfg["dt_minutes"],
        location_name=cfg["location_name"],
        return_period=cfg["return_period"],
        duration_hours=cfg["duration_hours"],
        depth_unit=depth_unit,
        apply_reduction=cfg.get("apply_reduction", False),
    )
    summary = pd.DataFrame(
        [
            {
                "location_name": cfg["location_name"],
                "station_name": cfg.get("station_name"),
                "site_id": cfg.get("site_id"),
                "latitude": cfg["latitude"],
                "longitude": cfg["longitude"],
                "return_period": cfg["return_period"],
                "duration_hours": cfg["duration_hours"],
                "dt_minutes": cfg["dt_minutes"],
                "peak_ratio": cfg["peak_ratio"],
                "units": cfg["units"],
                "idf_a": a,
                "idf_b": b,
                "idf_c": c,
                "idf_r2": r2,
                "apply_reduction": cfg.get("apply_reduction", False),
            }
        ]
    )
    summary.to_csv(
        output_folder / "rainfall_generation_summary.csv",
        index=False,
    )
    print("Completed Algorithm 5")


if __name__ == "__main__":
    main()