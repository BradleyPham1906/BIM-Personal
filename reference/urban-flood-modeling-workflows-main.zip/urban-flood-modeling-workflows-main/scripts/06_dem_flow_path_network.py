# -------------------------------------------------------------
# Script: 06_dem_flow_path_network.py
# Description: Execute DEM based flow path network generation
#
# Author: Ashish Shrestha
# Last Updated: 05-01-2026
# -------------------------------------------------------------

from pathlib import Path
import sys
import yaml

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(REPO_ROOT))

from src.flowpaths.dem_flow_path_network import generate_dem_flow_path_network

def load_config(config_path):
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def get_config():
    local_config = REPO_ROOT / "configs" / "local.yml"
    example_config = REPO_ROOT / "configs" / "example.yml"
    if local_config.exists():
        return load_config(local_config)
    return load_config(example_config)

def main():
    config = get_config()
    cfg = config["flow_path_network"]
    print("Executing Algorithm 6: DEM-based flow path network...")

    generate_dem_flow_path_network(
        working_directory=cfg["work_dir"],
        input_dem=cfg["input_dem"],
        filled_dem=cfg["outputs"]["filled_dem"],
        flow_direction=cfg["outputs"]["flow_direction"],
        flow_accumulation=cfg["outputs"]["flow_accumulation"],
        flow_path_raster=cfg["outputs"]["flow_path_raster"],
        flow_order_raster=cfg["outputs"].get("flow_order_raster"),
        flow_path_vector=cfg["outputs"].get("flow_path_vector"),
        stream_threshold=cfg.get("stream_threshold", 1000),
        run_flow_order=cfg.get("run_flow_order", True),
        run_vector_conversion=cfg.get("run_vector_conversion", True),
        verbose=cfg.get("verbose", False),
    )
    print("Completed Algorithm 6")

if __name__ == "__main__":
    main()