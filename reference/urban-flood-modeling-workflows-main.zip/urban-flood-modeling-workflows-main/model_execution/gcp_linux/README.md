# HEC-RAS Linux Execution (GCP and Ubuntu)

This folder contains shell based execution templates for running HEC-RAS on Linux systems.

## Supported environments

These scripts are designed to work in:

- Google Cloud Platform (GCP) virtual machines
- Local Ubuntu/Linux systems

The same scripts can be used in both environments without modification, provided that HEC-RAS is properly installed.

## Required setup

Before using these scripts, download the official HEC-RAS Linux package from:

https://www.hec.usace.army.mil/software/hec-ras/download.aspx

For reference, this study used pre-compiled HEC-RAS version 6.6 and 6.7

After extraction, ensure the following structure exists:

```text
hecras/
  bin/
  libs/
  scripts/
```
## Additional Note

The `remove_HDF5_Results_Sed.py` script is required to remove Results data from the `.pXX.hdf` file prior to Linux execution.

This script is included in the official HEC-RAS Linux distribution and must be obtained from the USACE package.