#!/bin/sh
# ---------------------------------------------------------------
# Script: run_unsteady.sh
# Description: Execute HEC-RAS Unsteady Flow simulation on Linux
# Last edited: 04-30-2026
# ---------------------------------------------------------------

RAS_LIB_PATH="../libs:../libs/mkl:../libs/rhel_8"
RAS_EXE_PATH="../bin"

# Optional tuning (adjust based on available memory) ...
ulimit -s unlimited
export KMP_STACKSIZE=1G
# ...
export LD_LIBRARY_PATH="${RAS_LIB_PATH}:${LD_LIBRARY_PATH}"
export PATH="${RAS_EXE_PATH}:${PATH}"

../bin/RasUnsteady "$1" "$2"