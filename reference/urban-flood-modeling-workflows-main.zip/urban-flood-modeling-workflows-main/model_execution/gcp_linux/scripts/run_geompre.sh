#!/bin/sh
# ------------------------------------------------------------
# Script: run_geompre.sh
# Description: Run HEC-RAS Geometry Preprocessor on Linux
# Last edited: 04-30-2026
# ------------------------------------------------------------

RAS_LIB_PATH="../libs:../libs/mkl:../libs/rhel_8"
RAS_EXE_PATH="../bin"

export LD_LIBRARY_PATH="${RAS_LIB_PATH}:${LD_LIBRARY_PATH}"
export PATH="${RAS_EXE_PATH}:${PATH}"

../bin/RasGeomPreprocess "$1" "$2"