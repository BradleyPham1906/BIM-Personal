# HEC-RAS Execution on HPC (Slurm)

This folder provides templates for executing HEC-RAS simulations on High Performance Computing (HPC) clusters using a job scheduler (e.g., Slurm).

## Overview

HPC execution differs from standard Linux execution in that simulations are submitted as batch jobs rather than run interactively.

These templates support scalable execution of multiple HEC-RAS simulations across compute nodes.

## Requirements

- Access to an HPC system with a job scheduler (e.g., Slurm)
- Pre-installed HEC-RAS Linux binaries (`bin/`) and libraries (`libs/`)
- Proper environment configuration (modules or paths set by system administrators)

HEC-RAS binaries are not included in this repository and must be obtained from:

https://www.hec.usace.army.mil/software/hec-ras/download.aspx

For reference, this study used pre-compiled HEC-RAS version 6.6 and 6.7

## Execution workflow

### 1. Prepare model input files

Generate required files using the HEC-RAS Windows GUI:

```text
.bXX
.xXX
.pXX.hdf

## Example usage

Update variables in the Slurm script:

```bash
WORK_DIR="/scratch/user/project"
MODEL_NAME="my_model.p01"
PLAN_ID="x01"
WRAPPER="/path/to/run-hec-sas-6.6.bash"
REMOVE_SCRIPT="/path/to/remove_HDF5_Results_Sed.py"
```

## Additional Note

The `remove_HDF5_Results_Sed.py` script is required to remove Results data from the `.pXX.hdf` file prior to Linux execution.

This script is included in the official HEC-RAS Linux distribution and is not provided in this repository. Users must obtain it from the USACE HEC-RAS package.

The script should be referenced in the Slurm job script using:

```bash
REMOVE_SCRIPT="/path/to/remove_HDF5_Results_Sed.py"
```