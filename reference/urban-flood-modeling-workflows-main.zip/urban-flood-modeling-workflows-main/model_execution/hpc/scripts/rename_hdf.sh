#!/bin/bash
# ------------------------------------------------------------
# Script: rename_hdf.sh
# Description: Rename HEC-RAS temporary HDF files to final HDF files
#
# Author: Ashish Shrestha
# Last Updated: 05-01-2026
#
# Usage:
# ./rename_hdf.sh <model_base_name> <start_plan> <end_plan>
#
# Example:
# ./rename_hdf.sh Copenhagen_v1 1 9
# ------------------------------------------------------------

MODEL_BASE_NAME=$1
START_PLAN=$2
END_PLAN=$3

for i in $(seq "$START_PLAN" "$END_PLAN"); do
    plan_id=$(printf "%02d" "$i")
    tmp_file="${MODEL_BASE_NAME}.p${plan_id}.tmp.hdf"
    final_file="${MODEL_BASE_NAME}.p${plan_id}.hdf"

    if [ -f "$tmp_file" ]; then
        mv "$tmp_file" "$final_file"
    fi
done