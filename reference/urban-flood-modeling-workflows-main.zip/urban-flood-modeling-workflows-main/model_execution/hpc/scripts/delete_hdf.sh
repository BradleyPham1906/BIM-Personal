#!/bin/bash
# -----------------------------------------------------------------
# Script: delete_hdf.sh
# Description: Delete HEC-RAS plan HDF files for a range of plans
#
# Author: Ashish Shrestha
# Last Updated: 05-01-2026
#
# Usage:
# ./delete_hdf.sh <model_base_name> <start_plan> <end_plan>
#
# Example:
# ./delete_hdf.sh Copenhagen_v1 1 9
# ----------------------------------------------------------------

MODEL_BASE_NAME=$1
START_PLAN=$2
END_PLAN=$3

for i in $(seq "$START_PLAN" "$END_PLAN"); do
    plan_id=$(printf "%02d" "$i")
    file="${MODEL_BASE_NAME}.p${plan_id}.hdf"

    if [ -f "$file" ]; then
        rm -f "$file"
    fi
done