#!/bin/bash
#SBATCH --job-name=hecras_run
#SBATCH --output=hecras_run.out
#SBATCH --error=hecras_run.err
#SBATCH --time=19:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=64
#SBATCH --mem=36GB

# ------------------------------------------------------------
# Script: hecras_slurm.sh
# Description: Run HEC-RAS on an HPC cluster using Slurm
#
# Author: Ashish Shrestha
# Last Updated: 05-01-2026
# ------------------------------------------------------------

module purge

# User inputs
WORK_DIR="/path/to/hecras/project"
MODEL_NAME="model_name.p01"
PLAN_ID="x01"

WRAPPER="/path/to/run-hec-sas-6.6.bash"
REMOVE_SCRIPT="/path/to/remove_HDF5_Results_Sed.py"

PYTHON_MODULE="anaconda3/2025.06"

# Setup
cd "$WORK_DIR" || exit 1

module load "$PYTHON_MODULE"

# Prepare HDF (Note: Check README.md for required remove_HDF5_Results_Sed.py file)
python3 "$REMOVE_SCRIPT" "${MODEL_NAME}.hdf"

#  Run HEC-RAS 
"$WRAPPER" RasGeomPreprocess "${MODEL_NAME}.tmp.hdf" "$PLAN_ID" || \
"$WRAPPER" RasGeomPreprocess "${MODEL_NAME}.hdf" "$PLAN_ID"

"$WRAPPER" RasUnsteady "${MODEL_NAME}.tmp.hdf" "$PLAN_ID" || \
"$WRAPPER" RasUnsteady "${MODEL_NAME}.hdf" "$PLAN_ID"