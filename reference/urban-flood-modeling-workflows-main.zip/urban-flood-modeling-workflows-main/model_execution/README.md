# Model Execution Templates (HEC-RAS)

This folder provides platform specific templates for executing HEC-RAS simulations outside the Windows GUI environment.

## Overview

HEC-RAS Linux execution relies on precompiled compute engines and external runtime libraries. This repository does **not** include those binaries. Instead, it provides reproducible templates for running simulations in different environments.

## Execution environments

### `gcp_linux/`

Shell-based execution using SSH on Linux systems, including:

- Google Cloud Platform (GCP) virtual machines
- Local Ubuntu/Linux systems

These workflows use `.sh` scripts to:
- set required library paths
- call HEC-RAS executables (`RasGeomPreprocess`, `RasUnsteady`, `RasSteady`)
- manage simulation outputs (e.g., renaming `.tmp.hdf` files)

### `hpc/`

Batch based execution on High Performance Computing (HPC) systems using a job scheduler (e.g., Slurm).

These workflows include:
- Slurm job scripts for resource allocation (CPU, memory, wall time)
- helper Python scripts for managing HDF outputs (cleanup, renaming)

## Required HEC-RAS Linux setup

Users must download the official HEC-RAS Linux package from the USACE HEC-RAS website:

https://www.hec.usace.army.mil/software/hec-ras/download.aspx

For reference, this study used pre-compiled HEC-RAS version 6.6 and 6.7

After extraction, a typical structure should look like:

```text
hecras/
  bin/
  libs/
  scripts/