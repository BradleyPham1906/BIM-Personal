# -----------------------------------------------------------------------------------
# Module: dem_flow_path_network.py
# Description: Generate DEM based flow path network using WhiteboxTools
#
# Author: Ashish Shrestha
# Last Updated: 05-01-2026
# 
# Notes
#
# Dependency:
# whitebox is required for hydrologic terrain analysis.
# It provides open source tools for depression filling, D8 flow direction,
# flow accumulation, stream extraction, Strahler stream ordering, and
# raster to vector conversion.
#
# Installation note:
# pip install whitebox
# -----------------------------------------------------------------------------------

from pathlib import Path
from whitebox.whitebox_tools import WhiteboxTools

def generate_dem_flow_path_network(
    working_directory,
    input_dem,
    filled_dem,
    flow_direction,
    flow_accumulation,
    flow_path_raster,
    flow_order_raster=None,
    flow_path_vector=None,
    stream_threshold=1000,
    run_flow_order=True,
    run_vector_conversion=True,
    verbose=False,
):
    """
    
    Generate DEM based flow path network from an input DEM
    
    """
    working_directory = Path(working_directory)
    input_dem = Path(input_dem)

    if not input_dem.exists():
        raise FileNotFoundError(f"DEM not found: {input_dem}")
    working_directory.mkdir(parents=True, exist_ok=True)
    watershedtool = WhiteboxTools()
    watershedtool.work_dir = str(working_directory)
    watershedtool.verbose = verbose
    watershedtool.fill_depressions(
        dem=str(input_dem),
        output=str(filled_dem),
    )
    watershedtool.d8_pointer(
        dem=str(filled_dem),
        output=str(flow_direction),
    )
    watershedtool.d8_flow_accumulation(
        i=str(filled_dem),
        output=str(flow_accumulation),
        out_type="cells",
    )
    watershedtool.extract_streams(
        flow_accum=str(flow_accumulation),
        output=str(flow_path_raster),
        threshold=stream_threshold,
    )
    if run_flow_order:
        if flow_order_raster is None:
            raise ValueError("flow_order_raster must be provided when argument run_flow_order=True.") # check config

        watershedtool.strahler_stream_order(
            d8_pntr=str(flow_direction),
            streams=str(flow_path_raster),
            output=str(flow_order_raster),
        )
    if run_vector_conversion:
        if flow_path_vector is None:
            raise ValueError("flow_path_vector must be provided when argument run_vector_conversion=True.") # check config
        vector_input = flow_order_raster if run_flow_order else flow_path_raster
        watershedtool.raster_streams_to_vector(
            streams=str(vector_input),
            d8_pntr=str(flow_direction),
            output=str(flow_path_vector),
        )
    return {
        "filled_dem": filled_dem,
        "flow_direction": flow_direction,
        "flow_accumulation": flow_accumulation,
        "flow_path_raster": flow_path_raster,
        "flow_order_raster": flow_order_raster,
        "flow_path_vector": flow_path_vector,
    }