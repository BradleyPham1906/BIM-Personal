# ---------------------------------------------------------------------------------------------
# Module: download_overpass_osm.py
# Description: Download bridge and overpass line features from OpenStreetMap using Overpass API
#
# Author: Ashish Shrestha
# Last Updated: 04-28-2026
# ---------------------------------------------------------------------------------------------

from pathlib import Path
import time
import requests
import geopandas as gpd
from shapely.geometry import LineString


def download_osm_bridges(bbox, output_shapefile, reference_file=None):
    """
    
    Download bridge/overpass line features from OpenStreetMap
    
    """
    south, west, north, east = bbox

    query = f"""
    [out:json][timeout:180];
    (
      way["highway"]["bridge"="yes"]({south},{west},{north},{east});
    );
    out body;
    >;
    out skel qt;
    """
    endpoints = [
    "https://overpass.kumi.systems/api/interpreter",      
    "https://overpass.openstreetmap.fr/api/interpreter", 
    "https://overpass-api.de/api/interpreter",           
    ]
    result_json = None
    for endpoint in endpoints:
        for _ in range(3):
            try:
                response = requests.post(
                    endpoint,
                    data={"data": query},
                    timeout=180,
                    headers={"User-Agent": "urban-flood-modeling"},
                )
                if response.status_code == 200:
                    result_json = response.json()
                    break
            except Exception:
                pass
            time.sleep(5)

        if result_json:
            break

    if result_json is None:
        raise RuntimeError("Overpass API request failed.")

    nodes = {}
    records = []

    for el in result_json.get("elements", []):
        if el["type"] == "node":
            nodes[el["id"]] = (el["lon"], el["lat"])

    for el in result_json.get("elements", []):
        if el["type"] == "way":
            coords = [nodes[n] for n in el.get("nodes", []) if n in nodes]
            if len(coords) >= 2:
                records.append({"geometry": LineString(coords)})

    if not records:
        raise ValueError("No bridge features found.")
    gdf = gpd.GeoDataFrame(records, crs="EPSG:4326")

    if reference_file:
        gdf = gdf.to_crs(gpd.read_file(reference_file).crs)
    output_shapefile = Path(output_shapefile)
    output_shapefile.parent.mkdir(parents=True, exist_ok=True)
    gdf.to_file(output_shapefile)
    return output_shapefile