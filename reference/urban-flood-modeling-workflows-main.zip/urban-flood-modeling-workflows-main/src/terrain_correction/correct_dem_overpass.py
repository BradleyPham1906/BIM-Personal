# --------------------------------------------------------------------------------------
# Module: correct_dem_overpass.py
# Description: Correct DEM elevations at bridge/overpass locations using minimum filter
#
# Author: Ashish Shrestha
# Last Updated: 04-28-2026
# ---------------------------------------------------------------------------------------

from pathlib import Path
import numpy as np
import rasterio
from scipy.ndimage import minimum_filter


def apply_minimum_filter(dtm_raster, output_raster, filter_size=25):
    """
    
    Generate filtered DEM using a minimum filter
    
    """
    dtm_raster = Path(dtm_raster)
    output_raster = Path(output_raster)
    with rasterio.open(dtm_raster) as src:
        dtm_array = src.read(1)
        meta = src.meta.copy()
    filtered_dtm = minimum_filter(dtm_array, size=filter_size, mode="nearest")
    output_raster.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(output_raster, "w", **meta) as dst:
        dst.write(filtered_dtm, 1)
    return output_raster


def remove_overpass_elevations(dtm_raster, bridge_raster, filtered_dtm_raster, output_raster):
    """
    
    Replace bridge/overpass pixels in DEM with minimum-filtered elevations
    
    """
    dtm_raster = Path(dtm_raster)
    bridge_raster = Path(bridge_raster)
    filtered_dtm_raster = Path(filtered_dtm_raster)
    output_raster = Path(output_raster)
    with rasterio.open(dtm_raster) as dtm_src:
        dtm_array = dtm_src.read(1)
        meta = dtm_src.meta.copy()
    with rasterio.open(bridge_raster) as bridge_src:
        bridge_array = bridge_src.read(1)
    with rasterio.open(filtered_dtm_raster) as filtered_src:
        filtered_dtm = filtered_src.read(1)
    dtm_no_overpass = np.where(bridge_array == 1, filtered_dtm, dtm_array)
    output_raster.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(output_raster, "w", **meta) as dst:
        dst.write(dtm_no_overpass, 1)
    return output_raster