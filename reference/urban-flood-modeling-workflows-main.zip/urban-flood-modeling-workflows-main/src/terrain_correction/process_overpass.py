# -------------------------------------------------------------
# Module: process_overpass.py
# Description: Buffer and rasterize bridge/overpass features
#
# Author: Ashish Shrestha
# Last Updated: 04-28-2026
# -------------------------------------------------------------

from pathlib import Path
import geopandas as gpd
import rasterio
import numpy as np
from rasterio.features import rasterize
from shapely.geometry import mapping


def buffer_overpass_features(input_shapefile, output_shapefile, buffer_distance=15):
    """

    Buffer bridge/overpass line features. Change buffer_distance if needed.
    
    """
    input_shapefile = Path(input_shapefile)
    output_shapefile = Path(output_shapefile)
    gdf = gpd.read_file(input_shapefile)
    gdf["geometry"] = gdf.geometry.buffer(buffer_distance, cap_style=2)
    gdf["value"] = 1
    output_shapefile.parent.mkdir(parents=True, exist_ok=True)
    gdf.to_file(output_shapefile, driver="ESRI Shapefile")
    return output_shapefile


def rasterize_overpass_features(buffered_shapefile, reference_raster, output_raster):
    """
    
    Rasterize buffered bridge/overpass polygons to match reference raster
    
    """
    buffered_shapefile = Path(buffered_shapefile)
    reference_raster = Path(reference_raster)
    output_raster = Path(output_raster)
    gdf = gpd.read_file(buffered_shapefile)
    with rasterio.open(reference_raster) as src:
        meta = src.meta.copy()
        transform = src.transform
        height, width = src.shape
    shapes = ((mapping(geom), 1) for geom in gdf.geometry if geom is not None)
    bridge_array = rasterize(
        shapes,
        out_shape=(height, width),
        transform=transform,
        fill=0,
        dtype="uint8",
    )
    meta.update({"dtype": "uint8", "nodata": 0, "count": 1})
    output_raster.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(output_raster, "w", **meta) as dst:
        dst.write(bridge_array.astype(np.uint8), 1)
    return output_raster