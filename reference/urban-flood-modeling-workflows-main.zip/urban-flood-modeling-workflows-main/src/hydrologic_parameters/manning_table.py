# ---------------------------------------------------------------------------------
# Module: manning_table.py
# Description: Create Mannings n table from land cover / use classes present in raster
#
# Author: Ashish Shrestha
# Last Updated: 04-30-2026
# ---------------------------------------------------------------------------------

from pathlib import Path
import numpy as np
import pandas as pd
import rasterio

from src.hydrologic_parameters.lookup_tables import NLCD_MANNING


def create_manning_table(landuse_raster, output_csv):
    """
    
    Create Mannings n table for land-use classes present in raster
    
    """
    landuse_raster = Path(landuse_raster)
    output_csv = Path(output_csv)
    with rasterio.open(landuse_raster) as src:
        landuse_array = src.read(1)
        nodata = src.nodata
    unique_values = np.unique(landuse_array)
    if nodata is not None:
        unique_values = unique_values[unique_values != nodata]
    rows = []

    for landuse_id in sorted(unique_values):
        landuse_id = int(landuse_id)
        if landuse_id in NLCD_MANNING:
            landuse_name, manning_n = NLCD_MANNING[landuse_id]
            rows.append(
                {
                    "ID": landuse_id,
                    "Name": landuse_name,
                    "Manning_n": manning_n,
                }
            )
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows)
    df.to_csv(output_csv, index=False)
    return output_csv