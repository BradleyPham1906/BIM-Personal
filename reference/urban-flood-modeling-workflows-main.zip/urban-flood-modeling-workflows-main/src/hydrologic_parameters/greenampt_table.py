# -------------------------------------------------------------------------------
# Module: greenampt_table.py
# Description: Create Green Ampt parameter tables using soil and land cover / use data
#
# Author: Ashish Shrestha
# Last Updated: 04-30-2026
# -------------------------------------------------------------------------------

from pathlib import Path
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.features import rasterize

from src.hydrologic_parameters.lookup_tables import (
    SOIL_PARAMS,
    LANDUSE_MULTIPLIER,
)

def create_greenampt_row(
    class_id,
    name,
    suction,
    ksat,
    saturated,
    residual,
    pore_index,
    effective_saturation=0.44,
):
    """
    
    Create one Green Ampt parameter row
    
    """
    initial = residual + effective_saturation * (saturated - residual)
    return {
        "ID": class_id,
        "Name": name,
        "Wetting Front Suction (mm)": round(suction, 3),
        "Saturated Hydraulic Conductivity (mm/hr)": round(ksat, 3),
        "Initial Soil Water Content": round(initial, 3),
        "Saturated Soil Water Content": round(saturated, 3),
        "Residual Soil Water Content": round(residual, 3),
        "Pore Size Distribution Index": round(pore_index, 3),
    }

def create_greenampt_soil_only_table(
    soil_shapefile,
    output_csv,
    effective_saturation=0.44,
):
    """
    
    Create Green Ampt table using soil class only
    
    """
    soil_shapefile = Path(soil_shapefile)
    output_csv = Path(output_csv)
    soil = gpd.read_file(soil_shapefile)
    if "SoilClass" not in soil.columns:
        raise ValueError("Defined soil shapefile must contain a [SoilClass] field")
    rows = []
    for soil_id in sorted(soil["SoilClass"].dropna().unique()):
        soil_id = int(soil_id)
        if soil_id not in SOIL_PARAMS:
            continue
        soil_name, suction, ksat, saturated, residual, pore_index = SOIL_PARAMS[soil_id]
        row = create_greenampt_row(
            class_id=soil_id,
            name=soil_name,
            suction=suction,
            ksat=ksat,
            saturated=saturated,
            residual=residual,
            pore_index=pore_index,
            effective_saturation=effective_saturation,
        )
        row["SoilClass"] = soil_id
        row["SoilName"] = soil_name
        rows.append(row)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output_csv, index=False)
    return output_csv

def create_greenampt_soil_landuse_table(
    soil_shapefile,
    landuse_raster,
    output_csv,
    effective_saturation=0.44,
):
    """
    
    Create Green Ampt table using unique soil and land cover / use combinations
    
    """
    soil_shapefile = Path(soil_shapefile)
    landuse_raster = Path(landuse_raster)
    output_csv = Path(output_csv)
    soil = gpd.read_file(soil_shapefile)
    if "SoilClass" not in soil.columns:
        raise ValueError("Defined soil shapefile must contain a [SoilClass] field")
    with rasterio.open(landuse_raster) as src:
        soil_projected = soil.to_crs(src.crs)
        shapes = (
            (geom, int(soil_class))
            for geom, soil_class in zip(
                soil_projected.geometry,
                soil_projected["SoilClass"],
            )
            if geom is not None and not geom.is_empty
        )
        soil_raster = rasterize(
            shapes=shapes,
            out_shape=(src.height, src.width),
            transform=src.transform,
            fill=0,
            dtype="int16",
        )
        landuse_array = src.read(1)
        nodata = src.nodata
    valid_mask = soil_raster > 0
    if nodata is not None:
        valid_mask = valid_mask & (landuse_array != nodata)
    soil_lu_pairs = np.unique(
        np.stack(
            [soil_raster[valid_mask], landuse_array[valid_mask]],
            axis=1,
        ),
        axis=0,
    )
    rows = []
    for soil_id, landuse_id in soil_lu_pairs:
        soil_id = int(soil_id)
        landuse_id = int(landuse_id)
        if soil_id not in SOIL_PARAMS:
            continue
        if landuse_id not in LANDUSE_MULTIPLIER:
            continue
        soil_name, suction, ksat, saturated, residual, pore_index = SOIL_PARAMS[soil_id]
        landuse_name, ksat_multiplier, suction_multiplier = LANDUSE_MULTIPLIER[
            landuse_id
        ]
        combined_id = soil_id * 100 + landuse_id
        row = create_greenampt_row(
            class_id=combined_id,
            name=f"Class_{combined_id}",
            suction=suction * suction_multiplier,
            ksat=ksat * ksat_multiplier,
            saturated=saturated,
            residual=residual,
            pore_index=pore_index,
            effective_saturation=effective_saturation,
        )
        row["SoilClass"] = soil_id
        row["SoilName"] = soil_name
        row["LandUseID"] = landuse_id
        row["LandUseName"] = landuse_name
        row["Ksat_Multiplier"] = ksat_multiplier
        row["Suction_Multiplier"] = suction_multiplier
        rows.append(row)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output_csv, index=False)
    return output_csv