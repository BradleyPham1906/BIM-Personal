# --------------------------------------------------------------------
# Module: prepare_landuse.py
# Description: Download/use, extract, find, and clip land cover / use raster
#
# Author: Ashish Shrestha
# Last Updated: 04-30-2026
# --------------------------------------------------------------------

from pathlib import Path
import os
import zipfile
import requests
import geopandas as gpd
import rasterio
from rasterio.mask import mask

def download_file(url, output_path, max_retries=10):
    """
    
    Download a file with resume support as it is downloading large file NLCD 2021 (legacy version) for CONUS. Alternatively user can manually download latest version,
    then use that as the land cover layer.
    
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if output_path.exists() and zipfile.is_zipfile(output_path):
        return output_path
    headers_base = {"User-Agent": "Mozilla/5.0"}

    for _ in range(max_retries):
        existing_size = output_path.stat().st_size if output_path.exists() else 0
        headers = headers_base.copy()
        mode = "wb"
        if existing_size > 0:
            headers["Range"] = f"bytes={existing_size}-"
            mode = "ab"

        try:
            with requests.get(url, headers=headers, stream=True, timeout=120) as response:
                if response.status_code == 416:
                    if zipfile.is_zipfile(output_path):
                        return output_path
                    output_path.unlink(missing_ok=True)
                    continue
                if response.status_code not in [200, 206]:
                    response.raise_for_status()
                with open(output_path, mode) as f:
                    for chunk in response.iter_content(chunk_size=1024 * 1024):
                        if chunk:
                            f.write(chunk)
            if zipfile.is_zipfile(output_path):
                return output_path
        except Exception:
            continue
    raise RuntimeError("Error downloading after several tries.")


def unzip_file(zip_path, extract_folder):
    """
    
    Unzip file if extraction folder does not already exist
    
    """
    zip_path = Path(zip_path)
    extract_folder = Path(extract_folder)
    if extract_folder.exists() and any(extract_folder.iterdir()):
        return extract_folder
    if not zipfile.is_zipfile(zip_path):
        raise ValueError(f"Invalid or incomplete ZIP file: {zip_path}")
    extract_folder.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(extract_folder)
    return extract_folder


def find_landuse_raster(folder):
    """
    
    Find NLCD land cover raster inside extracted folder
    
    """
    folder = Path(folder)
    for root, _, files in os.walk(folder):
        for file_name in files:
            lower_name = file_name.lower()
            if lower_name.endswith((".img", ".tif")) and "land_cover" in lower_name:
                return Path(root) / file_name
    raise FileNotFoundError(f"Land cover raster is not found in: {folder}")


def clip_raster_to_boundary(raster_path, boundary_path, output_path):
    """
    
    Clip raster to a boundary polygon
    
    """
    raster_path = Path(raster_path)
    boundary_path = Path(boundary_path)
    output_path = Path(output_path)
    boundary = gpd.read_file(boundary_path)
    if boundary.empty:
        raise ValueError("Boundary shapefile error.")
    with rasterio.open(raster_path) as src:
        boundary_projected = boundary.to_crs(src.crs)
        geometries = [
            geom for geom in boundary_projected.geometry
            if geom is not None and not geom.is_empty
        ]
        clipped, clipped_transform = mask(src, geometries, crop=True)
        meta = src.meta.copy()
        meta.update(
            {
                "height": clipped.shape[1],
                "width": clipped.shape[2],
                "transform": clipped_transform,
                "compress": "lzw",
            }
        )
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with rasterio.open(output_path, "w", **meta) as dst:
            dst.write(clipped)
    return output_path

def prepare_landuse_raster(landuse_cfg, boundary_path):
    """
    Prepare land cover / use raster using either:
    1. NLCD download mode
    2. Local raster file mode

    """
    mode = landuse_cfg["mode"].lower()
    output_raster = Path(landuse_cfg["output_clipped_raster"])
    if output_raster.exists():
        return output_raster
    if mode == "nlcd":
        nlcd_cfg = landuse_cfg["nlcd"]
        zip_path = Path(nlcd_cfg["zip_path"])
        extract_folder = Path(nlcd_cfg["extract_folder"])
        download_file(
            url=nlcd_cfg["url"],
            output_path=zip_path,
            max_retries=nlcd_cfg.get("max_retries", 10),
        )
        unzip_file(zip_path, extract_folder)
        raw_landuse_raster = find_landuse_raster(extract_folder)
    elif mode == "local":
        raw_landuse_raster = Path(landuse_cfg["local_raster"])
        if not raw_landuse_raster.exists():
            raise FileNotFoundError(f"Local land cover / use raster not found: {raw_landuse_raster}")
    else:
        raise ValueError("Layer mode must be nlcd or local.")
    return clip_raster_to_boundary(
        raster_path=raw_landuse_raster,
        boundary_path=boundary_path,
        output_path=output_raster,
    )