# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Module: lookup_tables.py
# Description: Lookup tables for Mannings n and Green Ampt parameter assignment
#
# Author: Ashish Shrestha
# Last Updated: 04-30-2026
#
# NOTES:
# 1. Users can modify Manning’s n values based on:
# - literature values
# - calibration
# - site-specific conditions
# 2. Users can also modify multipliers to represent:
# - imperviousness
# - vegetation effects
# - compaction / urbanization
# 3. Parameters follow standard literature values (Please see: https://www.hec.usace.army.mil/confluence/rasdocs/r2dum/6.5/developing-a-terrain-model-and-geospatial-layers/infiltration-methods)
#   Thus, users can modify based on:
# - calibration
# - regional soil datasets
# - field measurements
#
# Units:
# suction → mm
# hydraulic conductivity → mm/hr
#
# Format:
# SoilClass:(Name, Wetting Front Suction(mm), Saturated Hydraulic Conductivity(mm/hr), Saturated Soil Water Content, Residual Soil Water Content, Pore Size Distribution Index) and initial soil water content is computed
# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# NLCD MANNING'S n LOOKUP
NLCD_MANNING = {
    11: ("Open Water", 0.030),
    12: ("Perennial Ice/Snow", 0.030),
    21: ("Developed, Open Space", 0.040),
    22: ("Developed, Low Intensity", 0.060),
    23: ("Developed, Medium Intensity", 0.080),
    24: ("Developed, High Intensity", 0.100),
    31: ("Barren Land", 0.030),
    41: ("Deciduous Forest", 0.120),
    42: ("Evergreen Forest", 0.130),
    43: ("Mixed Forest", 0.125),
    52: ("Shrub/Scrub", 0.080),
    71: ("Grassland", 0.035),
    81: ("Pasture/Hay", 0.040),
    82: ("Cultivated Crops", 0.050),
    90: ("Woody Wetlands", 0.100),
    95: ("Emergent Wetlands", 0.070),
}

# LAND USE MULTIPLIERS FOR GREEN-AMPT OPTION 2
LANDUSE_MULTIPLIER = {
    11: ("Open Water", 0.00, 1.00),
    21: ("Developed Open", 0.70, 1.05),
    22: ("Developed Low", 0.50, 1.10),
    23: ("Developed Medium", 0.30, 1.15),
    24: ("Developed High", 0.10, 1.20),
    41: ("Forest", 1.20, 0.95),
    52: ("Shrub", 0.90, 1.00),
    71: ("Grassland", 1.00, 1.00),
    81: ("Pasture", 0.90, 1.00),
    82: ("Crops", 0.80, 1.05),
    90: ("Wetlands", 0.50, 1.20),
}


# GREEN-AMPT SOIL PARAMETERS
SOIL_PARAMS = {
    1: ("Sand", 101.1, 222.8, 0.437, 0.020, 0.694),
    2: ("Loamy Sand", 130.8, 60.5, 0.437, 0.035, 0.553),
    3: ("Sandy Loam", 218.7, 23.9, 0.453, 0.041, 0.378),
    4: ("Loam", 245.0, 13.2, 0.463, 0.027, 0.252),
    5: ("Silt Loam", 366.8, 6.8, 0.501, 0.015, 0.234),
    6: ("Sandy Clay Loam", 493.7, 3.65, 0.398, 0.068, 0.319),
    7: ("Clay Loam", 427.5, 2.15, 0.464, 0.075, 0.242),
    8: ("Silty Clay Loam", 559.7, 1.75, 0.471, 0.040, 0.177),
    9: ("Sandy Clay", 551.3, 1.2, 0.430, 0.109, 0.223),
    10: ("Silty Clay", 612.4, 0.95, 0.479, 0.056, 0.150),
    11: ("Clay", 668.3, 0.6, 0.475, 0.090, 0.165),
    12: ("Impervious", 466.8, 0.1, 0.186, 0.185, 0.010),
}

# SOIL TEXTURE TO SOIL CLASS MAPPING
TEXTURE_TO_SOIL_ID = {
    "sand": 1,
    "loamy sand": 2,
    "sandy loam": 3,
    "loam": 4,
    "silt loam": 5,
    "sandy clay loam": 6,
    "clay loam": 7,
    "silty clay loam": 8,
    "sandy clay": 9,
    "silty clay": 10,
    "clay": 11,
    "bedrock": 12,
}