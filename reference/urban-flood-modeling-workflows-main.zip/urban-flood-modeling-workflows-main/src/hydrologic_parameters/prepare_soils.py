# ---------------------------------------------------------------------------------------
# Module: prepare_soils.py
# Description: Clip soil polygons and assign soil classes from class or texture fields
#
# Author: Ashish Shrestha
# Last Updated: 04-30-2026
# ---------------------------------------------------------------------------------------


from pathlib import Path
import re
import numpy as np
import pandas as pd
import geopandas as gpd

from src.hydrologic_parameters.lookup_tables import TEXTURE_TO_SOIL_ID

def clean_text(value):
    """
    
    Clean soil texture text for matching
    
    """
    if pd.isna(value):
        return ""
    value = str(value).lower().strip()
    value = re.sub(r"[^a-zA-Z\s]", " ", value)
    value = re.sub(r"\s+", " ", value)
    return value

def classify_soil_texture(texture):
    """
    
    Classify soil texture name into soil class ID
    
    """
    text = clean_text(texture)
    if text in TEXTURE_TO_SOIL_ID:
        return TEXTURE_TO_SOIL_ID[text]
    for key, soil_id in TEXTURE_TO_SOIL_ID.items():
        if key in text:
            return soil_id
    return np.nan

def clip_and_classify_soils(
    soil_shapefile,
    boundary_shapefile,
    output_shapefile,
    soil_class_column=None,
    soil_texture_column=None,
):
    """

    Clip soil polygons to boundary and assign a standardized SoilClass field.

    SoilClass can be assigned using either:
    1. A user-defined soil class column, or
    2. A user-defined soil texture column mapped to soil classes.

    """
    soil_shapefile = Path(soil_shapefile)
    boundary_shapefile = Path(boundary_shapefile)
    output_shapefile = Path(output_shapefile)
    boundary = gpd.read_file(boundary_shapefile)
    soil = gpd.read_file(soil_shapefile)
    if boundary.empty:
        raise ValueError("Boundary shapefile is empty.")
    if soil.empty:
        raise ValueError("Soil shapefile is empty.")
    soil = soil.to_crs(boundary.crs)
    soil_clip = gpd.clip(soil, boundary)
    if soil_clip.empty:
        raise ValueError("No soil polygons intersect the boundary.")
    available_columns = list(soil_clip.columns)
    if soil_class_column and soil_class_column in available_columns:
        soil_clip["SoilClass"] = (
            soil_clip[soil_class_column]
            .astype(float)
            .astype("Int64")
        )
    elif soil_texture_column and soil_texture_column in available_columns:
        soil_clip["SoilClass"] = (
            soil_clip[soil_texture_column]
            .apply(classify_soil_texture)
            .astype("Int64")
        )
    else:
        raise ValueError(
            "No valid soil classification column found.\n"
            f"Available columns: {available_columns}\n"
            f"Configured soil_class_column: {soil_class_column}\n"
            f"Configured soil_texture_column: {soil_texture_column}"
        )
    soil_clip = soil_clip.dropna(subset=["SoilClass"])
    soil_clip["SoilClass"] = soil_clip["SoilClass"].astype(int)
    output_shapefile.parent.mkdir(parents=True, exist_ok=True)
    soil_clip.to_file(output_shapefile)
    return output_shapefile