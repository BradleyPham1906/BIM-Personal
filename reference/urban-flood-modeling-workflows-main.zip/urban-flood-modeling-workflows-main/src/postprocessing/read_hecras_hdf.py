# -----------------------------------------------------------------------------------
# Module: read_hecras_hdf.py
# Description: Read HEC-RAS HDF 2D area coordinates and water surface results
#
# Author: Ashish Shrestha
# Last Updated: 05-01-2026
# -----------------------------------------------------------------------------------

import h5py
import numpy as np
from scipy.spatial import cKDTree

def get_2d_area_name(hdf_file):
    """
    
    Return matching 2D Flow Area name from geometry and results groups
    
    """
    geom_path = "Geometry/2D Flow Areas"
    result_path = (
        "Results/Unsteady/Output/Output Blocks/Base Output/"
        "Unsteady Time Series/2D Flow Areas"
    )
    geom_areas = list(hdf_file[geom_path].keys())
    result_areas = list(hdf_file[result_path].keys())
    common = [area for area in geom_areas if area in result_areas]
    if not common:
        raise ValueError(
            f"Matching 2D flow area is not found. "
            f"Geometry areas: {geom_areas}; Result areas: {result_areas}"
        )
    return common[0]

def read_hecras_2d_results(hdf_file):
    """
    
    Read cell center coordinates and water surface elevations from HEC-RAS HDF
    
    """
    with h5py.File(hdf_file, "r") as hdf:
        area_name = get_2d_area_name(hdf)
        coords_path = f"Geometry/2D Flow Areas/{area_name}/Cells Center Coordinate"
        water_path = (
            "Results/Unsteady/Output/Output Blocks/Base Output/"
            f"Unsteady Time Series/2D Flow Areas/{area_name}/Water Surface"
        )
        coords = hdf[coords_path][:]
        water_surface = hdf[water_path][:]
    return coords, water_surface, area_name

def estimate_cell_spacing(coords):
    """
    
    Estimate representative HEC-RAS cell spacing from cell center coordinates
    
    """
    valid_coords = coords[~np.isnan(coords).any(axis=1)]
    tree = cKDTree(valid_coords)
    distances, _ = tree.query(valid_coords, k=2)
    nearest_distances = distances[:, 1]
    nearest_distances = nearest_distances[nearest_distances > 0]
    return float(np.median(nearest_distances))