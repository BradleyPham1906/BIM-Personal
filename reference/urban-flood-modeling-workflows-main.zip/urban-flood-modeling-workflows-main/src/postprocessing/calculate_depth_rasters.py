# ------------------------------------------------------------------------------
# Module: calculate_depth_rasters.py
# Description: Convert HEC-RAS water surface outputs into flood depth rasters
# by reading hdf file
#
# Author: Ashish Shrestha
# Last Updated: 05-01-2026
# ------------------------------------------------------------------------------

from pathlib import Path
import numpy as np
import rasterio
from rasterio.enums import Resampling
from rasterio.transform import from_origin
from scipy.spatial import cKDTree


def unit_factor(from_unit, to_unit):
    """
    
    Return conversion factor between feet and meters
    
    """
    from_unit = from_unit.lower()
    to_unit = to_unit.lower()
    if from_unit == to_unit:
        return 1.0
    if from_unit in ["feet", "foot", "ft"] and to_unit in ["meter", "meters", "m"]:
        return 0.3048
    if from_unit in ["meter", "meters", "m"] and to_unit in ["feet", "foot", "ft"]:
        return 3.280839895
    raise ValueError(f"Unsupported unit conversion: {from_unit} to {to_unit}")


def get_resampling_method(method_name):
    """
    
    Return rasterio resampling method
    
    """
    resampling_methods = {
        "nearest": Resampling.nearest,
        "bilinear": Resampling.bilinear,
        "cubic": Resampling.cubic,
    }
    if method_name not in resampling_methods:
        raise ValueError("terrain_resampling_method must be 'nearest', 'bilinear', or 'cubic'.")
    return resampling_methods[method_name]


def create_output_grid(coords, hecras_grid_resolution, output_resolution):
    """
    
    Create output raster grid based on HEC-RAS cell center coordinates
    
    """
    valid_coords = coords[~np.isnan(coords).any(axis=1)]
    min_x = np.floor(
        (np.min(valid_coords[:, 0]) - hecras_grid_resolution) / output_resolution
    ) * output_resolution
    max_x = np.ceil(
        (np.max(valid_coords[:, 0]) + hecras_grid_resolution) / output_resolution
    ) * output_resolution
    min_y = np.floor(
        (np.min(valid_coords[:, 1]) - hecras_grid_resolution) / output_resolution
    ) * output_resolution
    max_y = np.ceil(
        (np.max(valid_coords[:, 1]) + hecras_grid_resolution) / output_resolution
    ) * output_resolution
    width = int(np.ceil((max_x - min_x) / output_resolution))
    height = int(np.ceil((max_y - min_y) / output_resolution))
    transform = from_origin(min_x, max_y, output_resolution, output_resolution)
    xs = min_x + (np.arange(width) + 0.5) * output_resolution
    ys = max_y - (np.arange(height) + 0.5) * output_resolution
    grid_x, grid_y = np.meshgrid(xs, ys)
    grid_points = np.column_stack(
        [
            grid_x.ravel(),
            grid_y.ravel(),
        ]
    )
    bounds = (min_x, min_y, max_x, max_y)
    return grid_points, height, width, transform, bounds


def read_terrain_to_grid(
    terrain_raster_path,
    bounds,
    height,
    width,
    terrain_resampling_method="bilinear",
):
    """
    
    Read terrain raster onto output grid
    
    """
    terrain_raster_path = Path(terrain_raster_path)
    min_x, min_y, max_x, max_y = bounds
    terrain_resampling = get_resampling_method(terrain_resampling_method)
    with rasterio.open(terrain_raster_path) as terrain_src:
        terrain_crs = terrain_src.crs
        terrain_nodata = terrain_src.nodata
        if terrain_nodata is None:
            terrain_nodata = -9999.0
        terrain_window = terrain_src.window(min_x, min_y, max_x, max_y)
        terrain_data = terrain_src.read(
            1,
            window=terrain_window,
            out_shape=(height, width),
            resampling=terrain_resampling,
        ).astype(np.float32)
    terrain_calc = terrain_data.copy()
    terrain_calc[terrain_calc == terrain_nodata] = np.nan
    return terrain_calc, terrain_crs, terrain_nodata


def write_depth_rasters(
    coords,
    water_surface_all,
    terrain_raster_path,
    output_dir,
    hecras_grid_resolution,
    model_units="meters",
    output_depth_units="meters",
    output_resolution=None,
    depth_threshold=0.001,
    timestep_minutes=5,
    max_search_distance=None,
    terrain_resampling_method="bilinear",
):
    """
    Generate flood-depth rasters from HEC-RAS 2D results.

    Steps:
    - Interpolate water surface elevations to a regular grid
    - Compute depth = WSE − terrain
    - Apply depth threshold
    - Export GeoTIFF rasters per timestep

    Parameters
    ----------
    coords : np.ndarray
        HEC-RAS cell center coordinates (n_cells × 2)
    water_surface_all : np.ndarray
        Water surface elevations (n_timesteps × n_cells)
    terrain_raster_path : str
        Path to terrain DEM
    hecras_grid_resolution : float
        HEC-RAS mesh resolution
    model_units : str
        Model units ("meters" or "feet")
    output_depth_units : str
        Output depth units
    Notes
    -----
    - Terrain and HEC-RAS data must share CRS and units
    
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    if output_resolution is None:
        output_resolution = hecras_grid_resolution
    if max_search_distance is None:
        max_search_distance = hecras_grid_resolution * 0.75
    depth_conversion = unit_factor(model_units, output_depth_units)
    grid_points, height, width, transform, bounds = create_output_grid(
        coords=coords,
        hecras_grid_resolution=hecras_grid_resolution,
        output_resolution=output_resolution,
    )
    terrain_calc, terrain_crs, terrain_nodata = read_terrain_to_grid(
        terrain_raster_path=terrain_raster_path,
        bounds=bounds,
        height=height,
        width=width,
        terrain_resampling_method=terrain_resampling_method,
    )
    profile = {
        "driver": "GTiff",
        "height": height,
        "width": width,
        "count": 1,
        "dtype": "float32",
        "crs": terrain_crs,
        "transform": transform,
        "nodata": terrain_nodata,
        "compress": "lzw",
    }
    depth_paths = []
    for index in range(water_surface_all.shape[0]):
        time_suffix = f"{(index + 1) * timestep_minutes}min"
        water_surface = water_surface_all[index, :]
        valid_mask = (
            ~np.isnan(coords[:, 0])
            & ~np.isnan(coords[:, 1])
            & ~np.isnan(water_surface)
        )
        if np.sum(valid_mask) == 0:
            continue
        valid_xy = coords[valid_mask]
        valid_wse = water_surface[valid_mask].astype(np.float32)
        tree = cKDTree(valid_xy)
        distances, indices = tree.query(
            grid_points,
            k=1,
            distance_upper_bound=max_search_distance,
        )
        wse_grid = np.full(grid_points.shape[0], np.nan, dtype=np.float32)
        good = np.isfinite(distances)
        wse_grid[good] = valid_wse[indices[good]]
        wse_grid = wse_grid.reshape((height, width))
        depth = wse_grid - terrain_calc
        depth[
            np.isnan(depth)
            | (depth < depth_threshold)
        ] = terrain_nodata
        if output_depth_units.lower() not in ["meter", "meters", "m"]:
            valid_depth_mask = depth != terrain_nodata
            depth[valid_depth_mask] = depth[valid_depth_mask] * depth_conversion
        depth_path = output_dir / f"water_depth_{time_suffix}.tif"
        with rasterio.open(depth_path, "w", **profile) as dst:
            dst.write(depth.astype(np.float32), 1)
        depth_paths.append(depth_path)
    return depth_paths