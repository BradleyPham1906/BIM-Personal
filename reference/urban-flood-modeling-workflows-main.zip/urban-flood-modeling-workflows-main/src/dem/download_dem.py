# -------------------------------------------------------------
# Module: download_dem.py
# Description: Download USGS DEM tiles durectly from URLs
#
# Author: Ashish Shrestha
# Last Updated: 04-28-2026
# -------------------------------------------------------------

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import requests


def read_dem_urls(url_file):
    """

    Read DEM download URLs from a text file
    
    """
    url_file = Path(url_file)
    if not url_file.exists():
        raise FileNotFoundError(f"DEM URL file not found: {url_file}")
    with open(url_file, "r", encoding="utf-8") as f:
        urls = [line.strip() for line in f if line.strip()]
    if not urls:
        raise ValueError(f"No URLs found in: {url_file}")
    return urls


def download_file(url, output_dir):
    """

    Download a single DEM file from a URL

    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    filename = url.split("/")[-1]
    output_path = output_dir / filename
    if output_path.exists():
        print(f"Skipping existing file: {output_path.name}")
        return output_path
    print(f"Downloading: {filename}")
    response = requests.get(url, stream=True, timeout=120)
    response.raise_for_status()
    with open(output_path, "wb") as f:
        for chunk in response.iter_content(chunk_size=8192):
            if chunk:
                f.write(chunk)
    return output_path


def download_dem_files(urls, output_dir, max_workers=10):
    """

    Download multiple DEM files in parallel
    
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        downloaded_files = list(
            executor.map(lambda url: download_file(url, output_dir), urls)
        )
    return downloaded_files