# -------------------------------------------------------------
# Module: mosaic_dem.py
# Description: Combine downloaded DEM tiles
#
# Author: Ashish Shrestha
# Last Updated: 04-28-2026
# -------------------------------------------------------------

from pathlib import Path
import rasterio
from rasterio.merge import merge


def mosaic_rasters(input_folder, output_path, pattern="*.tif"):
    """
    
    Mosaic DEM raster tiles into a single GeoTIFF
    
    """
    input_folder = Path(input_folder)
    output_path = Path(output_path)
    tif_files = sorted(input_folder.glob(pattern))
    if not tif_files:
        raise FileNotFoundError(f"Error finding raster files in {input_folder}")
    src_files = [rasterio.open(path) for path in tif_files]
    try:
        mosaic, out_transform = merge(src_files)

        out_meta = src_files[0].meta.copy()
        out_meta.update(
            {
                "driver": "GTiff",
                "height": mosaic.shape[1],
                "width": mosaic.shape[2],
                "transform": out_transform,
                "compress": "lzw",
                "BIGTIFF": "YES",
            }
        )
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with rasterio.open(output_path, "w", **out_meta) as dst:
            dst.write(mosaic)
        return output_path
    finally:
        for src in src_files:
            src.close()