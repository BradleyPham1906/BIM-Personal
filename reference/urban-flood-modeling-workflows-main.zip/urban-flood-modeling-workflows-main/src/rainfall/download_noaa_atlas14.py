# -----------------------------------------------------------------------
# Module: download_noaa_atlas14.py
# Description: Download NOAA Atlas 14 precipitation-frequency depth table
#
# Author: Ashish Shrestha
# Last Updated: 04-30-2026
# -----------------------------------------------------------------------

from pathlib import Path
import shutil
from pfdf.data.noaa import atlas14

def safe_label(value):
    """
    
    Create file-safe labels from numeric or string values
    
    """
    return str(value).replace(".", "p").replace("-", "m").replace(" ", "")

def get_atlas_units(units):
    """
    
    Convert user unit setting to NOAA Atlas 14 unit setting
    
    """
    if units == "in":
        return "english", "in", "in/hr"
    if units == "mm":
        return "metric", "mm", "mm/hr"
    raise ValueError("Units should be: in or mm")

def download_atlas14_depth_table(
    latitude,
    longitude,
    output_folder,
    location_name,
    units="mm",
    overwrite=True,
):
    """
    
    Download NOAA Atlas 14 depth table and return CSV path
    
    """
    output_folder = Path(output_folder)
    output_folder.mkdir(parents=True, exist_ok=True)
    atlas_units, _, _ = get_atlas_units(units)
    csv_name = (
        f"NOAA_Atlas14_Depth_{atlas_units}_"
        f"{location_name}_lat{safe_label(latitude)}_lon{safe_label(longitude)}.csv"
    )
    final_csv = output_folder / csv_name
    downloaded_path = atlas14.download(
        lat=latitude,
        lon=longitude,
        parent=output_folder,
        name=csv_name,
        overwrite=overwrite,
        data="depth",
        series="pds",
        units=atlas_units,
    )
    downloaded_path = Path(downloaded_path)
    if downloaded_path.resolve() != final_csv.resolve():
        shutil.copy2(downloaded_path, final_csv)
    return final_csv