# -------------------------------------------------------------
# Module: plot_hyetograph.py
# Description: Plot Chicago design storm hyetograph
#
# Author: Ashish Shrestha
# Last Updated: 04-30-2026
# -------------------------------------------------------------

from pathlib import Path
import matplotlib.pyplot as plt

def plot_hyetograph(
    hyetograph,
    output_file,
    dt_minutes,
    location_name,
    return_period,
    duration_hours,
    depth_unit,
    apply_reduction=True,
):
    """
    
    Plot original and reduced hyetograph
    
    """
    output_file = Path(output_file)
    plt.rcParams["font.family"] = "Arial"
    fig, ax = plt.subplots(figsize=(9, 4.5))
    bar_width = dt_minutes * 0.85
    ax.bar(
        hyetograph["time_min"],
        hyetograph["depth"],
        width=bar_width,
        align="edge",
        alpha=0.55,
        label="Original rainfall",
    )
    if apply_reduction and "reduced_depth" in hyetograph.columns:
        ax.bar(
            hyetograph["time_min"],
            hyetograph["reduced_depth"],
            width=bar_width,
            align="edge",
            alpha=0.65,
            label="Reduced rainfall",
        )
    ax.set_xlabel("Time (min)", fontsize=12)
    ax.set_ylabel(
        f"Rainfall depth per interval ({depth_unit})",
        fontsize=12,
    )
    ax.set_title(
        f"{location_name}: Chicago Design Storm "
        f"{return_period}-yr, {duration_hours}-hr",
        fontsize=13,
    )
    ax.tick_params(axis="both", labelsize=11)
    ax.legend(frameon=False, fontsize=11)
    fig.tight_layout()
    fig.savefig(output_file, dpi=300, bbox_inches="tight")
    plt.close(fig)
    return output_file