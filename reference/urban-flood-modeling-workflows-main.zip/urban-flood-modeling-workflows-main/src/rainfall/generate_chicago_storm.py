# -----------------------------------------------------------------------------------------
# Module: generate_chicago_storm.py
# Description: Generate Chicago design storm hyetograph from fitted IDF parameters
#
# Author: Ashish Shrestha
# Last Updated: 04-30-2026
# -----------------------------------------------------------------------------------------

import numpy as np
import pandas as pd

def chicago_intensity_hnh(t, duration_minutes, a, b, c, r):
    """
    
    Compute Chicago storm intensity at time t
    
    """
    peak_time = r * duration_minutes
    if t < peak_time:
        time_before_peak = peak_time - t
        x = time_before_peak / r + b
        return a * (((1 - c) * (time_before_peak / r) + b) / (x ** (1 + c)))
    if t > peak_time:
        time_after_peak = t - peak_time
        x = time_after_peak / (1 - r) + b
        return a * (((1 - c) * (time_after_peak / (1 - r)) + b) / (x ** (1 + c)))
    return a / (b ** c)

def idf_average_intensity(dt_minutes, a, b, c):
    """
    
    Compute average IDF intensity for one time interval
    
    """
    return a / ((dt_minutes + b) ** c)

def chicago_hyetograph_hnh(duration_hours, dt_minutes, a, b, c, r):
    """
    
    Generate Chicago design storm hyetograph
    
    """
    duration_minutes = duration_hours * 60.0
    dt = float(dt_minutes)
    dt_hours = dt / 60.0
    number_of_steps = int(round(duration_minutes / dt))
    peak_time = r * duration_minutes
    time_edges = np.linspace(0, duration_minutes, number_of_steps + 1)
    depth = np.zeros(number_of_steps, dtype=float)
    for index in range(number_of_steps):
        t0 = time_edges[index]
        t1 = time_edges[index + 1]
        if (t0 <= peak_time) and (t1 >= peak_time):
            intensity = idf_average_intensity(dt, a, b, c)
        else:
            midpoint_time = 0.5 * (t0 + t1)
            intensity = chicago_intensity_hnh(
                midpoint_time,
                duration_minutes,
                a,
                b,
                c,
                r,
            )
        depth[index] = intensity * dt_hours
    time_min = np.arange(0, number_of_steps) * dt
    intensity = depth / dt_hours
    return pd.DataFrame(
        {
            "time_min": time_min,
            "depth": depth,
            "intensity": intensity,
        }
    )