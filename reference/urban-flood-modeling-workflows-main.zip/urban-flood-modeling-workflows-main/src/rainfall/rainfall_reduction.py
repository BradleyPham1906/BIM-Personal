# -----------------------------------------------------------------------------
# Module: rainfall_reduction.py
# Description: Apply rainfall reduction using total storm depth capacity method
#
# Author: Ashish Shrestha
# Last Updated: 04-30-2026
# -----------------------------------------------------------------------------

import pandas as pd

def compute_reduction_factor(original_depth, design_depth):
    """
    
    Compute reduction factor based on total storm depth capacity
    
    """
    if original_depth <= design_depth:
        return 0.0
    return 1.0 - (design_depth / original_depth)

def apply_rainfall_reduction(hyetograph, reduction_factor):
    """
    
    Apply reduction factor to hyetograph
    
    """
    hy = hyetograph.copy()
    hy["reduction_factor_RT"] = reduction_factor
    hy["reduced_depth"] = hy["depth"] * reduction_factor
    hy["reduced_intensity"] = hy["intensity"] * reduction_factor
    return hy