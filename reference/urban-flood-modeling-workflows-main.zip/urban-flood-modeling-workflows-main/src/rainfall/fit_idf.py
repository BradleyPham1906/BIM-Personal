# -----------------------------------------------------------------
# Module: fit_idf.py
# Description: Fit IDF relationship from NOAA Atlas 14 depth table
#
# Author: Ashish Shrestha
# Last Updated: 04-30-2026
# -----------------------------------------------------------------

import numpy as np
import pandas as pd
from scipy.optimize import curve_fit

def idf_func(t, a, b, c):
    """
    
    IDF function: i(t) = a / (t + b)^c
    
    """
    return a / ((t + b) ** c)

def fit_idf(noaa_table, return_period, max_fit_minutes=24 * 60):
    """
    
    Fit IDF parameters for a selected return period
    
    """
    if return_period not in noaa_table.columns:
        available = [
            col for col in noaa_table.columns
            if col not in ["Duration", "minutes"]
        ]
        raise ValueError(
            f"Return period '{return_period}' not found. "
            f"Available return periods: {available}"
        )
    fit = noaa_table.loc[
        noaa_table["minutes"] <= max_fit_minutes,
        ["minutes", return_period],
    ].copy()
    fit[return_period] = pd.to_numeric(fit[return_period], errors="coerce")
    fit = fit.dropna()
    t_min = fit["minutes"].to_numpy(float)
    depth = fit[return_period].to_numpy(float)
    intensity = depth / (t_min / 60.0)
    (a, b, c), _ = curve_fit(
        idf_func,
        t_min,
        intensity,
        p0=[1000.0, 10.0, 0.7],
        bounds=([0.0, 0.0, 0.0], [np.inf, np.inf, 5.0]),
        maxfev=200000,
    )
    predicted = idf_func(t_min, a, b, c)
    ss_res = np.sum((intensity - predicted) ** 2)
    ss_tot = np.sum((intensity - np.mean(intensity)) ** 2)
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else np.nan
    return a, b, c, r2