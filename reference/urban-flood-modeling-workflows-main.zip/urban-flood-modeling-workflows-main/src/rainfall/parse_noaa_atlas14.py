# ------------------------------------------------------------------------------
# Module: parse_noaa_atlas14.py
# Description: Parse NOAA Atlas 14 precipitation-frequency depth CSV tables
#
# Author: Ashish Shrestha
# Last Updated: 04-30-2026
# ------------------------------------------------------------------------------

from pathlib import Path
import numpy as np
import pandas as pd

def duration_to_minutes(duration_string):
    """
    
    Convert NOAA Atlas 14 duration labels to minutes
    
    """
    text = str(duration_string).strip().replace(":", "")
    if "min" in text:
        return float(text.split("-")[0])
    if "hr" in text:
        return float(text.split("-")[0]) * 60.0
    if "day" in text:
        return float(text.split("-")[0]) * 1440.0
    return np.nan

def read_noaa_csv(file_path):
    """
    
    Read NOAA Atlas 14 CSV and return depth table with duration in minutes
    
    """
    lines = Path(file_path).read_text(errors="ignore").splitlines()
    header_index = None
    for index, line in enumerate(lines):
        if line.lower().startswith("by duration"):
            header_index = index
            break
    if header_index is None:
        raise ValueError("Error with Atlas14 CSV")
    header_parts = [part.strip() for part in lines[header_index].split(",")]
    return_periods = [part.strip() for part in header_parts[1:] if part.strip()]
    rows = []
    for line in lines[header_index + 1:]:
        if not line.strip():
            break
        if line.lower().startswith("date/time") or line.lower().startswith("pyruntime"):
            break
        parts = [part.strip() for part in line.split(",")]
        duration = parts[0].replace(":", "").strip()
        values = [value.strip() for value in parts[1:] if value.strip() != ""]
        rows.append([duration] + values)
    noaa = pd.DataFrame(rows, columns=["Duration"] + return_periods)
    noaa["minutes"] = noaa["Duration"].apply(duration_to_minutes)
    return noaa, return_periods

def get_noaa_depth(noaa_table, return_period, duration_hours):
    """
    
    Extract NOAA depth for a given return period and duration
    
    """
    duration_minutes = duration_hours * 60.0
    matched = noaa_table.loc[np.isclose(noaa_table["minutes"], duration_minutes)]
    if matched.empty:
        raise ValueError(
            f"Unable to find given duration {duration_hours} hr "
            f"({duration_minutes} min) in NOAA Atlas 14 table."
        )
    depth = pd.to_numeric(matched[return_period].iloc[0], errors="coerce")
    if pd.isna(depth):
        raise ValueError(
            f"Unable to read depth for {return_period}-yr, "
            f"{duration_hours}-hr."
        )
    return float(depth)