# -------------------------------------------------------------
# Module: process_buildings.py
# Description: Project, clip, and assign building heights
#
# Author: Ashish Shrestha
# Last Updated: 04-28-2026
# -------------------------------------------------------------

from pathlib import Path
import geopandas as gpd
import rasterio
from shapely.geometry import box
import pandas as pd


def project_and_clip_buildings(building_shapefile, dem_raster, output_shapefile):
    """

    Project building footprints to DEM CRS and clip to DEM extent
    
    """
    building_shapefile = Path(building_shapefile)
    dem_raster = Path(dem_raster)
    output_shapefile = Path(output_shapefile)

    with rasterio.open(dem_raster) as dem:
        dem_crs = dem.crs
        dem_bounds = dem.bounds

    buildings = gpd.read_file(building_shapefile)
    buildings_proj = buildings.to_crs(dem_crs)# Reproject to DEM CRS
    dem_extent = gpd.GeoDataFrame(  # Create DEM extent polygon
        {"geometry": [box(*dem_bounds)]}, crs=dem_crs
    )
    buildings_clip = buildings_proj.overlay(dem_extent, how="intersection") # Clip buildings
    buildings_clip = buildings_clip[  # Remove invalid geometries
        buildings_clip.geometry.notna() & buildings_clip.geometry.is_valid
    ]
    output_shapefile.parent.mkdir(parents=True, exist_ok=True)
    buildings_clip.to_file(output_shapefile, driver="ESRI Shapefile")
    return output_shapefile



def assign_building_heights(
    input_shapefile,
    output_shapefile,
    fallback_height=2.0,
    use_height_attribute=True,
):
    """
    Assign building heights

    Two options:
    1. use_height_attribute = True → use height field if available, fallback otherwise
    2. use_height_attribute = False → assign constant fallback height to all buildings (as done in this study)

    """
    input_shapefile = Path(input_shapefile)
    output_shapefile = Path(output_shapefile)

    gdf = gpd.read_file(input_shapefile)

    # Option 1: Use height attribute + fallback
    if use_height_attribute:
        if "height" in gdf.columns and pd.api.types.is_numeric_dtype(gdf["height"]):
            gdf["new_height"] = gdf["height"].apply(
                lambda h: h if pd.notna(h) and h > 0 else fallback_height
            )
        else:
            gdf["new_height"] = fallback_height

    # Option 2: Constant fallback height (user defined, change in config file (.yml))
    else:
        gdf["new_height"] = fallback_height

    output_shapefile.parent.mkdir(parents=True, exist_ok=True)
    gdf.to_file(output_shapefile, driver="ESRI Shapefile")

    return output_shapefile