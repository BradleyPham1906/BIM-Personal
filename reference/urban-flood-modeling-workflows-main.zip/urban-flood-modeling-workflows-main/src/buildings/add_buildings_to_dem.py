# -------------------------------------------------------------
# Module: add_buildings_to_dem.py
# Description: Integrate building heights into DEM to create DSM
#
# Author: Ashish Shrestha
# Last Updated: 04-28-2026
# -------------------------------------------------------------

from pathlib import Path
import numpy as np
import rasterio


def add_buildings_to_dem(dem_raster, building_raster, output_dem):
    """
    Add rasterized building heights to DEM elevations.

    Building heights are added only where:
    - building raster value > 0
    - DEM pixel is valid

    """
    dem_raster = Path(dem_raster)
    building_raster = Path(building_raster)
    output_dem = Path(output_dem)

    output_dem.parent.mkdir(parents=True, exist_ok=True)

    with rasterio.open(dem_raster) as dem_src, rasterio.open(building_raster) as building_src:
        meta = dem_src.meta.copy()
        nodata_val = meta.get("nodata")
        if nodata_val is None:
            nodata_val = -9999
            meta["nodata"] = nodata_val
        meta.update(
            dtype="float32",
            count=1,
            compress="lzw",
            BIGTIFF="YES",
        )

        with rasterio.open(output_dem, "w", **meta) as dst:
            for _, window in dem_src.block_windows(1):
                dem_data = dem_src.read(1, window=window)
                building_data = building_src.read(1, window=window)
                valid_mask = dem_data != nodata_val
                combined = np.where(
                    (building_data > 0) & valid_mask,
                    dem_data + building_data,
                    dem_data,
                )
                combined[~valid_mask] = nodata_val
                dst.write(combined.astype("float32"), 1, window=window)
    return output_dem