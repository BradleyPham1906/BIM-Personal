# -------------------------------------------------------------
# Module: rasterize_buildings.py
# Description: Convert building polygons to raster
#
# Author: Ashish Shrestha
# Last Updated: 04-28-2026
# -------------------------------------------------------------

from pathlib import Path
import geopandas as gpd
import rasterio
from rasterio.features import rasterize


def rasterize_buildings(buildings_shapefile, reference_dem, output_raster):
    """
    Rasterize building polygons using the new_height field.
    Output raster matches the reference DEM extent, resolution, CRS, and transform.

    """
    buildings_shapefile = Path(buildings_shapefile)
    reference_dem = Path(reference_dem)
    output_raster = Path(output_raster)

    buildings = gpd.read_file(buildings_shapefile)
    buildings = buildings[buildings.geometry.notnull() & buildings.geometry.is_valid]

    if "new_height" not in buildings.columns:
        raise ValueError("Input building shapefile must contain a new_height field.")

    with rasterio.open(reference_dem) as dem:
        transform = dem.transform
        out_shape = dem.shape
        crs = dem.crs

    shapes = [
        (geom, height)
        for geom, height in zip(buildings.geometry, buildings["new_height"])
    ]

    building_array = rasterize(
        shapes=shapes,
        out_shape=out_shape,
        transform=transform,
        fill=0,
        dtype="float32",
    )

    output_raster.parent.mkdir(parents=True, exist_ok=True)

    with rasterio.open(
        output_raster,
        "w",
        driver="GTiff",
        height=out_shape[0],
        width=out_shape[1],
        count=1,
        dtype="float32",
        crs=crs,
        transform=transform,
        compress="lzw",
    ) as dst:
        dst.write(building_array, 1)

    return output_raster