# -------------------------------------------------------------
# Module: download_overture_buildings.py
# Description: Download building footprints from OvertureMaps and convert to shapefile. For reference: https://github.com/OvertureMaps/overturemaps-py. 
# The bounding box coordinates as defined in config can be generated from this tool: https://boundingbox.klokantech.com/
#
# Author: Ashish Shrestha
# Last Updated: 04-28-2026
# -------------------------------------------------------------

from pathlib import Path
import subprocess
import geopandas as gpd
import os


def download_overture_buildings(bbox, output_geojson, overturemaps_exe):
    """
    
    Download OvertureMaps building footprints as GeoJSON
    
    """
    output_geojson = Path(output_geojson)
    output_geojson.parent.mkdir(parents=True, exist_ok=True)

    if isinstance(bbox, list):
        bbox = ",".join(str(value) for value in bbox)

    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"

    subprocess.run(
        [
            overturemaps_exe,
            "download",
            "--bbox",
            bbox,
            "--type",
            "building",
            "-f",
            "geojson",
            "-o",
            str(output_geojson),
        ],
        check=True,
        env=env,
    )

    return output_geojson

def convert_geojson_to_shapefile(input_geojson, output_shapefile):
    """
    
    Convert building GeoJSON to ESRI Shapefile
    
    """
    input_geojson = Path(input_geojson)
    output_shapefile = Path(output_shapefile)
    output_shapefile.parent.mkdir(parents=True, exist_ok=True)
    gdf = gpd.read_file(input_geojson)
    gdf.to_file(output_shapefile, driver="ESRI Shapefile")
    return output_shapefile