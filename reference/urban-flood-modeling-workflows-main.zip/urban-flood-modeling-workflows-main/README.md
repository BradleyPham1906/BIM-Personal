# urban-flood-modeling-workflows
Scalable, interoperable, and reproducible workflows for high-resolution urban flood modeling using 2D hydrodynamic models

## Repository Structure

```text
urban-flood-modeling-workflows/
│
├── .github/
│   └── CODEOWNERS
│
├── configs/
│   └── example.yml # Sample configuration file (edit paths and parameters as needed)
│
├── model_execution/
│   ├── gcp_linux/
│   │   ├── scripts/
│   │   │   ├── run_geompre.sh
│   │   │   └── run_unsteady.sh
│   │   └── README.md
│   │
│   ├── hpc/
│   │   ├── scripts/
│   │   │   ├── delete_hdf.sh
│   │   │   ├── rename_hdf.sh
│   │   │   └── hecras_slurm.sh
│   │   └── README.md
│   │
│   └── README.md
│
├── scripts/
│   ├── 01_dem_acquisition_processing.py
│   ├── 02_building_dem_integration.py
│   ├── 03_overpass_removal.py
│   ├── 04_landuse_soil_parameter_assignment.py
│   ├── 05_generate_chicago_design_storm.py
│   ├── 06_dem_flow_path_network.py
│   └── 07_hecras_execution_postprocessing.py
│
├── src/
│   ├── buildings/
│   │   ├── add_buildings_to_dem.py
│   │   ├── download_overture_buildings.py
│   │   ├── process_buildings.py
│   │   └── rasterize_buildings.py
│   │
│   ├── dem/
│   │   ├── download_dem.py
│   │   ├── mosaic_dem.py
│   │   └── clip_dem.py   # placeholder module
│   │
│   ├── flowpaths/
│   │   └── dem_flow_path_network.py
│   │
│   ├── rainfall/
│   │   ├── download_noaa_atlas14.py
│   │   ├── parse_noaa_atlas14.py
│   │   ├── fit_idf.py
│   │   ├── generate_chicago_storm.py
│   │   ├── rainfall_reduction.py
│   │   └── plot_hyetograph.py
│   │
│   ├── hydrologic_parameters/
│   │   ├── prepare_landuse.py
│   │   ├── prepare_soils.py
│   │   ├── greenampt_table.py
│   │   ├── manning_table.py
│   │   └── lookup_tables.py
│   │
│   ├── postprocessing/
│   │   ├── read_hecras_hdf.py
│   │   └── calculate_depth_rasters.py
│   │
│   └── terrain_correction/
│       ├── download_overpass_osm.py
│       ├── process_overpass.py
│       └── correct_dem_overpass.py
│
├── .gitattributes
├── .gitignore
├── AUTHORS.md
├── CITATION.cff
├── LICENSE
└── README.md

```

## Overview

This repository provides a scalable, interoperable, and reproducible workflows for high-resolution urban flood modeling using 2D hydrodynamic models.

The workflow automates:
- Acquisition of geospatial datasets (USGS DEM, OvertureMaps, OSM, NLCD)
- Terrain preprocessing and correction (buildings, overpasses)
- Hydrologic parameter assignment (Green-Ampt, Manning’s n coefficient)
- Design storm generation using location specific NOAA Atlas 14 by programmatically acquiring intensity-duration-frequency tables
- Rainfall reduction to approximate stormwater drainage capacity
- DEM-based flow path network extraction
- Model execution (e.g., HEC-RAS) across local, GCP, and HPC environments
- Postprocessing of HEC-RAS outputs into flood depth rasters

## Data Sources and Usage

This workflow leverages publicly available geospatial and hydrometeorological datasets to enable scalable, interoperable, and reproducible urban flood modeling. While the current study and examples focus on the United States using publicly available datasets (e.g., USGS, NLCD, NOAA Atlas 14, OvertureMaps, OpenStreetMap), the workflow can be extended to global datasets such as Shuttle Radar Topography Mission (SRTM, 30 m DEM), Copernicus GLO-30 (30 m DEM), Copernicus Land Cover, and NASA Global Land Cover Mapping products.

The figure below summarizes the primary data sources and derived datasets relevant to this workflow.

![Data Sources](docs/figures/data_sources_flood.jpg)

## Getting Started

### 1. Clone the repository

```bash
git clone https://github.com/UrbanSystemsLab/urban-flood-modeling-workflows.git
cd urban-flood-modeling-workflows
```

### 2. Configure inputs
Edit:
```bash
configs/example.yml
```
## Citation

If you use this repository, please cite:

Shrestha, A., Mustafa, A., Sagade, C., Kennedy, C., McPhearson, T. (2026).  
**Advancing Urban Flood Modeling: A Scalable, Interoperable and Reproducible High-Resolution Modeling Framework and Workflow.**

BibTeX:

```bibtex
@article{shrestha2026urbanflood,
  title={Advancing Urban Flood Modeling: A Scalable, Interoperable and Reproducible High-Resolution Modeling Framework and Workflow},
  author={Shrestha, Ashish and Mustafa, Ahmed and Sagade, Chinmay and Kennedy, Christopher and McPhearson, Timon},
  year={2026}
}
```